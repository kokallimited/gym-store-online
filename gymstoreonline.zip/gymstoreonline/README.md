# GymStoreOnline.com

A professional gym equipment review and affiliate website built for the Amazon Associates Program.

## Site Structure

```
gymstoreonline/
├── index.html           # Homepage with hero, 5 product carousels, blog preview, videos
├── blog.html            # Blog listing page with sidebar
├── blog-post-1.html     # Article: Best Olympic Barbells 2025
├── blog-post-2.html     # Article: Treadmill vs Rowing Machine
├── privacy-policy.html  # GDPR-compliant privacy policy
├── cookie-policy.html   # Full cookie policy with opt-out info
├── terms.html           # Terms and conditions
├── css/
│   └── style.css        # Full stylesheet (dark theme, Bebas Neue + DM Sans)
└── js/
    └── main.js          # Carousels, cookie banner, mobile nav, scroll reveal
```

## Features

- **5 product carousels**: Barbells, Cardio, Benches, Supplements, Cable Machines
- **2 full blog posts** with affiliate CTAs and product recommendations
- **3 legal pages**: Privacy Policy, Cookie Policy, Terms & Conditions
- Amazon affiliate disclosure on every page (header + footer)
- Cookie consent banner with localStorage persistence
- Responsive mobile navigation
- Scroll reveal animations
- YouTube video section with real thumbnails
- Newsletter signup form
- SEO meta tags and canonical URLs on all pages

## Amazon Associates Setup

Before going live, replace all instances of `YOUR-ASSOCIATE-TAG` with your real Amazon Associates tracking ID.

Search and replace: `YOUR-ASSOCIATE-TAG` → `yoursite-20` (or your actual tag)

## Deployment

### GitHub Pages
1. Push this folder to a GitHub repository
2. Go to Settings → Pages → Source: Deploy from a branch → `main` / `root`
3. Your site will be live at `https://yourusername.github.io/gymstoreonline/`
4. Point `gymstoreonline.com` DNS to GitHub Pages (CNAME record)

### Custom Domain
Add a `CNAME` file to the root containing:
```
gymstoreonline.com
```

## Amazon Associates Compliance

This site is built to meet Amazon Associates requirements:
- ✅ Affiliate disclosure on every page (top of page + footer)
- ✅ Legal pages (Privacy Policy, Cookie Policy, Terms)
- ✅ Original content (blog posts, buying guides)
- ✅ No Amazon logo or branding used
- ✅ Links open Amazon search results (not direct product pages — update with real ASINs once account approved)
- ✅ `rel="nofollow noopener"` on all affiliate links
- ✅ "Opens Amazon.com" note under each product CTA

## Next Steps After Amazon Approval
1. Replace search-based Amazon URLs with actual ASIN product URLs
2. Add real product images (Amazon PA API or manual)
3. Connect Google Analytics (add GA4 tracking code to all pages)
4. Set up newsletter (Mailchimp embed)
5. Submit sitemap to Google Search Console
