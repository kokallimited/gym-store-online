// ── COOKIE BANNER ──
(function() {
  const banner = document.getElementById('cookieBanner');
  if (!banner) return;
  const accepted = localStorage.getItem('gsoCookieConsent');
  if (!accepted) {
    setTimeout(() => banner.classList.add('show'), 800);
  }
  document.getElementById('cookieAccept')?.addEventListener('click', () => {
    localStorage.setItem('gsoCookieConsent', 'accepted');
    banner.classList.remove('show');
  });
  document.getElementById('cookieDecline')?.addEventListener('click', () => {
    localStorage.setItem('gsoCookieConsent', 'declined');
    banner.classList.remove('show');
  });
})();

// ── MOBILE NAV ──
(function() {
  const hamburger = document.getElementById('hamburger');
  const mobileNav = document.getElementById('mobileNav');
  if (!hamburger || !mobileNav) return;
  hamburger.addEventListener('click', () => {
    mobileNav.classList.toggle('open');
  });
})();

// ── CAROUSELS ──
function initCarousel(sectionId) {
  const section = document.getElementById(sectionId);
  if (!section) return;
  const track = section.querySelector('.carousel-track');
  const cards = section.querySelectorAll('.product-card');
  const prevBtn = section.querySelector('.carousel-prev');
  const nextBtn = section.querySelector('.carousel-next');
  if (!track || cards.length === 0) return;

  let currentIndex = 0;
  const visibleCount = () => {
    if (window.innerWidth <= 480) return 1;
    if (window.innerWidth <= 768) return 2;
    if (window.innerWidth <= 1024) return 3;
    return 4;
  };
  const maxIndex = () => Math.max(0, cards.length - visibleCount());

  function updateCarousel() {
    const cardWidth = cards[0].offsetWidth + 20;
    track.style.transform = `translateX(-${currentIndex * cardWidth}px)`;
    if (prevBtn) prevBtn.style.opacity = currentIndex === 0 ? '0.3' : '1';
    if (nextBtn) nextBtn.style.opacity = currentIndex >= maxIndex() ? '0.3' : '1';
  }

  prevBtn?.addEventListener('click', () => {
    currentIndex = Math.max(0, currentIndex - 1);
    updateCarousel();
  });
  nextBtn?.addEventListener('click', () => {
    currentIndex = Math.min(maxIndex(), currentIndex + 1);
    updateCarousel();
  });

  window.addEventListener('resize', updateCarousel);
  updateCarousel();
}

document.addEventListener('DOMContentLoaded', () => {
  initCarousel('carousel-barbells');
  initCarousel('carousel-cardio');
  initCarousel('carousel-benches');
  initCarousel('carousel-supplements');
  initCarousel('carousel-cables');
});

// ── NEWSLETTER FORM ──
document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('newsletterForm');
  if (!form) return;
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const btn = form.querySelector('button');
    const originalText = btn.textContent;
    btn.textContent = 'Subscribed! ✓';
    btn.style.background = '#22c55e';
    setTimeout(() => {
      btn.textContent = originalText;
      btn.style.background = '';
      form.reset();
    }, 3000);
  });
});

// ── ACTIVE NAV ──
document.addEventListener('DOMContentLoaded', () => {
  const path = window.location.pathname;
  document.querySelectorAll('.nav a, .mobile-nav a').forEach(link => {
    const href = link.getAttribute('href') || '';
    if (
      (path.endsWith(href) && href !== 'index.html') ||
      (path === '/' && href === 'index.html') ||
      (path.includes(href) && href !== 'index.html' && href !== '/')
    ) {
      link.classList.add('active');
    }
  });
});

// ── SCROLL REVEAL ──
document.addEventListener('DOMContentLoaded', () => {
  if (!('IntersectionObserver' in window)) return;
  const elements = document.querySelectorAll('.blog-card, .product-card, .why-card, .video-card, .category-card');
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateY(0)';
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1 });
  elements.forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(16px)';
    el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
    observer.observe(el);
  });
});
